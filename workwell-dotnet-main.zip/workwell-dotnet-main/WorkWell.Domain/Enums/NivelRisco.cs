namespace WorkWell.Domain.Enums;

public enum NivelRisco
{
    Baixo = 0,
    Moderado = 1,
    Alto = 2,
    Critico = 3
}

