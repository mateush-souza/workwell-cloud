namespace WorkWell.Domain.Enums;

public enum UserRole
{
    USER = 0,
    ADMIN = 1
}

